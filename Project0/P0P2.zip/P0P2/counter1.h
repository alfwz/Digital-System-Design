#include "systemc.h"

SC_MODULE(counter1){
	sc_in< sc_uint<8> > in1;
	sc_in<bool> clock, load1, dec1, c1_hold;
	sc_out< sc_uint<8> > count1;
	sc_out<bool> overflow1;
	//method
	void prc_counter1();
	
	//internal connection 
	sc_uint<8> count, count_temp;
	
	//constructor
	SC_CTOR(counter1){
		SC_METHOD(prc_counter1);
		sensitive<<clock.pos();
	}
};

void counter1 :: prc_counter1(){
	if(load1){
		count=in1;
		count_temp=count;
	}
	else if(c1_hold){}
	else if(dec1){
		count= count-1;
		count_temp=count;
	}
	count1=count;
	if(count_temp<count){
		overflow1 = true;
		count1=count_temp;
	}
}
